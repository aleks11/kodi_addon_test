import sys
import urllib
import urlparse
import xbmcgui
import xbmcplugin
import os
import xbmcaddon

import logging
logging.basicConfig(filename='/home/aleks/.kodi/temp/kodi.log', level=logging.INFO,
                    format='%(asctime)s - %(levelname)s - %(message)s')


base_url = sys.argv[0]
addon_handle = int(sys.argv[1])
args = urlparse.parse_qs(sys.argv[2][1:])

xbmcplugin.setContent(addon_handle, 'movies')

mode = args.get('mode', None)

addonPath = xbmcaddon.Addon().getAddonInfo("path")
fanart_main = os.path.join(addonPath, 'resources', 'images', 'fanart_main.jpg')

class Addon:
    def __init__( self ):
        if mode is None or mode[0] == 'settings':
            logging.info('start')
        else:
            makelogin_data = None


    def main_menu(self):
        self.addMenuItem({'mode': 'categories', 'foldername': 'categories'}, None, True)
        self.addMenuItem({'mode': 'folder', 'foldername': 'latest', 'start': '0'}, None, True)
        self.addMenuItem({'mode': 'search', 'foldername': 'search', 'start': '0', 'word-q': '0'}, None, True)
        self.addMenuItem({'mode': 'my_favorites', 'foldername': 'favorites'}, None, True)
        self.addMenuItem({'mode': 'my_downloads', 'foldername': 'my_downloads'}, None, True)
        self.addMenuItem({'mode': 'settings', 'foldername': 'settings'}, None, False)

    def build_url(self, query):
        return base_url + '?' + urllib.urlencode(query)


    def addMenuItem(self, params, iconImage, isFolder):
        url = self.build_url(params)
        li = xbmcgui.ListItem(params['foldername'])
        li.setArt({'fanart': fanart_main})
        url2 = self.build_url({'mode': 'settings', 'foldername': 'settings'})
        settings = ('test', 'XBMC.RunPlugin(' + url2 + ')')
        li.addContextMenuItems([settings], replaceItems=True)
        xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=isFolder)



if ( __name__ == "__main__" ):
    if mode is None:
        # display main menu
        getattr(Addon(), 'main_menu')()
    elif hasattr(Addon(), mode[0]):
        logging.info('mode: '+mode[0])
        getattr(Addon(), mode[0])()
    else:
        logging.info('die')

    xbmcplugin.endOfDirectory(addon_handle)
    logging.info('end addon.py')
    exit(0)
